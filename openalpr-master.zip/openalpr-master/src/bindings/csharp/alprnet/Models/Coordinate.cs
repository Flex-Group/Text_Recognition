﻿

namespace AlprNet.Models
{
    public class Coordinate
    {
        public int x { get; set; }
        public int y { get; set; }
    }
}
