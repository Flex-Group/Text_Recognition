﻿

namespace AlprNet.Models
{
    public class RegionOfInterest
    {
        public int x { get; set; }
        public int y { get; set; }
        public int width { get; set; }
        public int height { get; set; }
    }
}
